import { requireSession } from "@/lib/api-auth"
import { logAudit } from "@/lib/audit"
import { db } from "@/lib/db"
import {
  division,
  merchant,
  order,
  pickupLocation,
  warehouse,
} from "@/lib/db/schema"
import { divisionUpdateSchema, parseBody } from "@/lib/validation"
import { and, eq, ne } from "drizzle-orm"
import { forbidden, notFound, unauthorized } from "@/lib/api-response"
import { NextResponse } from "next/server"

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const me = await requireSession()
  if (!me) return unauthorized()
  if (me.role !== "SUPER_ADMIN") {
    return forbidden()
  }

  const { id } = await params
  const parsed = await parseBody(req, divisionUpdateSchema)
  if (parsed.error) return parsed.error
  const { name, isActive } = parsed.data

  const updates: { name?: string; isActive?: boolean } = {}
  if (name !== undefined) {
    const trimmed = name.trim()
    const [clash] = await db
      .select({ id: division.id })
      .from(division)
      .where(and(eq(division.name, trimmed), ne(division.id, id)))
      .limit(1)
    if (clash) {
      return NextResponse.json(
        { error: "A division with that name already exists." },
        { status: 409 },
      )
    }
    updates.name = trimmed
  }
  if (isActive !== undefined) updates.isActive = isActive

  const [updated] = await db
    .update(division)
    .set(updates)
    .where(eq(division.id, id))
    .returning()

  if (!updated) return notFound()

  await logAudit({
    actor: { userId: me.userId, name: me.name, role: me.role },
    action: "DIVISION_UPDATED",
    entityType: "division",
    entityId: updated.id,
    description: `Updated division ${updated.name}`,
    metadata: updates,
  })

  return NextResponse.json(updated)
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const me = await requireSession()
  if (!me) return unauthorized()
  if (me.role !== "SUPER_ADMIN") {
    return forbidden()
  }

  const { id } = await params

  const [warehouseRef] = await db
    .select({ id: warehouse.id })
    .from(warehouse)
    .where(eq(warehouse.divisionId, id))
    .limit(1)
  const [merchantRef] = await db
    .select({ id: merchant.id })
    .from(merchant)
    .where(eq(merchant.divisionId, id))
    .limit(1)
  const [pickupRef] = await db
    .select({ id: pickupLocation.id })
    .from(pickupLocation)
    .where(eq(pickupLocation.divisionId, id))
    .limit(1)
  const [orderRef] = await db
    .select({ id: order.id })
    .from(order)
    .where(eq(order.deliveryDivisionId, id))
    .limit(1)

  if (warehouseRef || merchantRef || pickupRef || orderRef) {
    return NextResponse.json(
      {
        error:
          "This division is in use by warehouses, merchants, pickup locations, or orders and cannot be deleted. Deactivate it instead.",
      },
      { status: 409 },
    )
  }

  const [existing] = await db
    .select({ name: division.name })
    .from(division)
    .where(eq(division.id, id))
    .limit(1)

  await db.delete(division).where(eq(division.id, id))

  await logAudit({
    actor: { userId: me.userId, name: me.name, role: me.role },
    action: "DIVISION_DELETED",
    entityType: "division",
    entityId: id,
    description: `Deleted division ${existing?.name ?? id}`,
  })

  return NextResponse.json({ ok: true })
}
